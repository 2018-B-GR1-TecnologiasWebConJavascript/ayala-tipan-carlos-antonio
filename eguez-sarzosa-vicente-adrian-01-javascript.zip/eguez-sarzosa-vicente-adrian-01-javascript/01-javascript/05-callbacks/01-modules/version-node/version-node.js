// version-node/version-node.js
module.exports = '8.12.0';