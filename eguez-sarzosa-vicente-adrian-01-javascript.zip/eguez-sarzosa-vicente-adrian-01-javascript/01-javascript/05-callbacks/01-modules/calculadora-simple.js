// calculadora-simple.js

module.exports = {
    nombreCalculadora: 'Super calc',
    sumar: (a, b) => a + b,
    restar: (a, b) => a - b,
    multiplicar: (a, b) => a * b,
    dividir: (a, b) => a / b,
    version: '0.0.1',
    autor: 'Adrian Eguez'
};