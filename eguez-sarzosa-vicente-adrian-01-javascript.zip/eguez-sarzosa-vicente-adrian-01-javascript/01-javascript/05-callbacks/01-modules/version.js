// version.js
module.exports = '1.0.0';


const noMeVoyAExportar = null;
