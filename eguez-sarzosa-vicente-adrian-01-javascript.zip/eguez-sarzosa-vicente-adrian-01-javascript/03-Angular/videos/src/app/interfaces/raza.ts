export interface Raza {
  id?: number;
  nombre: string;
  createdAt?: number;
  updatedAt?: number;
}
