import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-perfil',
  templateUrl: './ruta-perfil.component.html',
  styleUrls: ['./ruta-perfil.component.scss']
})
export class RutaPerfilComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
