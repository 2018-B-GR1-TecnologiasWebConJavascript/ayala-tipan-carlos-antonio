import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-menu',
  templateUrl: './ruta-menu.component.html',
  styleUrls: ['./ruta-menu.component.scss']
})
export class RutaMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
