import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta404',
  templateUrl: './ruta404.component.html',
  styleUrls: ['./ruta404.component.scss']
})
export class Ruta404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
